<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <script type='text/javascript' src='https://cdn.prinsh.com/NathanPrinsley-effect/green-bintang-jatuh.js'></script>

    <link rel="icon" href="jabat.png" type="image/x-icon">
    <title>Selamat Hari Raya Idul Fitri</title>
</head>
<body class="bg">
    <style type="text/css">
        .bg{
          background: url('idul.png') no-repeat center;
          background-size: cover;
          padding: 100px 40px;
          text-align: center;
          color: white;
        }
    </style>
    <!-- Djazuli IT -->
    
    <div class="greetings" >
    <!-- silahkan menambah kata sesuai keinginan dengan <span>text...</span -->
        <span>A</span>
        <span>S</span>
        <span>S</span>
        <span>A</span>
        <span>L</span>
        <span>A</span>
        <span>M</span>
        <span>U</span>
        <span>A</span>
        <span>L</span>
        <span>A</span>
        <span>I</span>
        <span>K</span>
        <span>U</span>
        <span>M</span>

    </div>
    <form method="get" action="flower.php">
    <div class="login">

          <div class="avatar">
            <img src="fitri.gif" width="50">
          </div>

          <h2>Ketikkan Nama Kamu, dibawah!!</h2>

          <div class="box-login">
            <input type="text" name="nama" placeholder="Ketik Nama Kamu">
          </div>

          <button type="submit" class="btn-login"><img src="jabat.png"><br> Lahir Batin</button>
          
      </div>
      </form>
      <h2 class="g">Devoloped Djazuli</h2>
      <audio loop="true" autoplay="true">
    <source src="fitri.mp3" type="audio/mpeg">
</audio>
</body>
</html>
